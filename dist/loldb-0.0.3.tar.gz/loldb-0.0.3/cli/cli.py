

def main():
    print("Testing the cli")